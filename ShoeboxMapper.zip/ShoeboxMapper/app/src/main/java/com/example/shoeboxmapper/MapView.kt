package com.example.shoeboxmapper

import android.content.Context
import android.graphics.*
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.view.GestureDetector
import android.view.MotionEvent
import android.view.View
import java.io.File
import kotlin.math.hypot
import kotlin.math.min
import kotlin.math.sin

enum class Kind { COLOR, PULSE, STRIPES, MEDIA, CHECKER, RAINBOW, VIDEO }

/** pts = TL, TR, BR, BL as x,y pairs in "wall space" (the space of the reference photo). */
class Quad(
    var pts: FloatArray,
    var kind: Kind = Kind.PULSE,
    var color: Int = Color.WHITE,
    var mediaFile: String? = null
) {
    var drawable: Drawable? = null
    var video: VideoSource? = null
}

class MapView(context: Context) : View(context) {
    val quads = mutableListOf<Quad>()
    var photo: Bitmap? = null
    var showPhoto = true
    var projecting = false
    var flipH = false
    var flipV = false
    var fine = false
    var selected = -1
    var corner = -1
    var onToggle: (() -> Unit)? = null

    private val dp = resources.displayMetrics.density
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val stroke = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2f * dp }
    private val photoPaint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = 150 }
    private val videoPaint = Paint(Paint.FILTER_BITMAP_FLAG)
    private val path = Path()
    private val loupePath = Path()
    private val warp = Matrix()
    private var dragging = false
    private var lastX = 0f
    private var lastY = 0f
    private var fingerX = 0f

    private val detector = GestureDetector(context, object : GestureDetector.SimpleOnGestureListener() {
        override fun onDoubleTap(e: MotionEvent): Boolean {
            if (projecting) onToggle?.invoke()
            return true
        }
    })

    init { keepScreenOn = true }

    override fun verifyDrawable(who: Drawable): Boolean =
        quads.any { it.drawable === who } || super.verifyDrawable(who)

    // ---------- editing API ----------
    fun addQuad() {
        val w = width.toFloat(); val h = height.toFloat()
        val l = w * 0.3f; val r = w * 0.7f; val t = h * 0.2f; val b = h * 0.6f
        quads.add(Quad(floatArrayOf(l, t, r, t, r, b, l, b)))
        selected = quads.lastIndex; corner = -1
        invalidate()
    }

    fun deleteSelected() {
        if (selected in quads.indices) quads.removeAt(selected).video?.release()
        selected = -1; corner = -1
        invalidate()
    }

    fun moveCorner(dx: Float, dy: Float) {
        quads.getOrNull(selected)?.let { if (corner >= 0) { it.pts[corner * 2] += dx; it.pts[corner * 2 + 1] += dy } }
        invalidate()
    }

    fun moveQuad(dx: Float, dy: Float) { quads.getOrNull(selected)?.let { shift(it, dx, dy) }; invalidate() }
    fun moveAll(dx: Float, dy: Float) { quads.forEach { shift(it, dx, dy) }; invalidate() }

    private fun shift(q: Quad, dx: Float, dy: Float) {
        for (i in 0..3) { q.pts[i * 2] += dx; q.pts[i * 2 + 1] += dy }
    }

    fun zoomAll(f: Float) {
        val cx = width / 2f; val cy = height / 2f
        quads.forEach { q ->
            for (i in 0..3) {
                q.pts[i * 2] = cx + (q.pts[i * 2] - cx) * f
                q.pts[i * 2 + 1] = cy + (q.pts[i * 2 + 1] - cy) * f
            }
        }
        invalidate()
    }

    fun loadMedia(q: Quad) {
        val f = q.mediaFile ?: return
        q.video?.release(); q.video = null
        if (q.kind == Kind.VIDEO) {
            q.video = VideoSource(File(context.filesDir, f)).also { it.start() }
            return
        }
        try {
            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(File(context.filesDir, f)))
            d.setFilterBitmap(false) // crisp pixel art
            if (d is AnimatedImageDrawable) {
                d.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                d.callback = this
                d.start()
            }
            q.drawable = d
        } catch (e: Exception) {
            q.drawable = null
        }
    }

    fun pauseVideos() { quads.forEach { it.video?.pause() } }
    fun resumeVideos() { quads.forEach { it.video?.resume() } }

    override fun onDetachedFromWindow() {
        quads.forEach { it.video?.release() }
        super.onDetachedFromWindow()
    }

    // ---------- drawing ----------
    override fun onDraw(c: Canvas) {
        c.drawColor(Color.BLACK)
        drawScene(c)
        if (dragging && corner >= 0 && selected in quads.indices) drawLoupe(c)
        postInvalidateOnAnimation()
    }

    private fun drawScene(c: Canvas) {
        c.save()
        c.scale(if (flipH) -1f else 1f, if (flipV) -1f else 1f, width / 2f, height / 2f)
        val t = System.currentTimeMillis()
        if (!projecting && showPhoto) photo?.let { p ->
            val s = min(width / p.width.toFloat(), height / p.height.toFloat())
            val w = p.width * s; val h = p.height * s
            c.drawBitmap(p, null, RectF((width - w) / 2, (height - h) / 2, (width + w) / 2, (height + h) / 2), photoPaint)
        }
        quads.forEach { drawQuad(c, it, t) }
        if (!projecting) quads.forEachIndexed { i, q -> drawHandles(c, q, i == selected) }
        c.restore()
    }

    private fun quadPath(q: Quad) {
        path.reset()
        path.moveTo(q.pts[0], q.pts[1])
        for (i in 1..3) path.lineTo(q.pts[i * 2], q.pts[i * 2 + 1])
        path.close()
    }

    private fun drawQuad(c: Canvas, q: Quad, t: Long) {
        val d = q.drawable
        val vb = q.video?.bitmap
        val sw = when {
            q.kind == Kind.MEDIA && d != null -> d.intrinsicWidth.toFloat()
            q.kind == Kind.VIDEO && vb != null -> vb.width.toFloat()
            else -> 400f
        }
        val sh = when {
            q.kind == Kind.MEDIA && d != null -> d.intrinsicHeight.toFloat()
            q.kind == Kind.VIDEO && vb != null -> vb.height.toFloat()
            else -> 400f
        }
        val src = floatArrayOf(0f, 0f, sw, 0f, sw, sh, 0f, sh)
        if (!warp.setPolyToPoly(src, 0, q.pts, 0, 4)) return
        quadPath(q)
        c.save()
        c.clipPath(path)
        c.concat(warp)
        when (q.kind) {
            Kind.COLOR -> { fill.color = q.color; c.drawRect(0f, 0f, sw, sh, fill) }
            Kind.PULSE -> {
                fill.color = q.color
                fill.alpha = (50 + 205 * (0.5 + 0.5 * sin(t / 350.0))).toInt()
                c.drawRect(0f, 0f, sw, sh, fill)
            }
            Kind.STRIPES -> {
                fill.color = q.color
                var x = -80f + (t / 15 % 80).toFloat()
                while (x < sw) { c.drawRect(x, 0f, x + 40f, sh, fill); x += 80f }
            }
            Kind.RAINBOW -> {
                fill.color = Color.HSVToColor(floatArrayOf((t / 12 % 360).toFloat(), 1f, 1f))
                c.drawRect(0f, 0f, sw, sh, fill)
            }
            Kind.CHECKER -> {
                fill.color = q.color
                val o = (t / 25 % 100).toFloat()
                for (iy in -3..9) for (ix in -3..9) if (((ix + iy) and 1) == 0)
                    c.drawRect(ix * 50f + o, iy * 50f + o, ix * 50f + o + 50f, iy * 50f + o + 50f, fill)
            }
            Kind.VIDEO -> vb?.let { c.drawBitmap(it, 0f, 0f, videoPaint) }
            Kind.MEDIA -> d?.let { it.setBounds(0, 0, sw.toInt(), sh.toInt()); it.draw(c) }
        }
        c.restore()
    }

    private fun drawHandles(c: Canvas, q: Quad, sel: Boolean) {
        quadPath(q)
        stroke.color = if (sel) Color.YELLOW else Color.WHITE
        c.drawPath(path, stroke)
        for (i in 0..3) {
            fill.color = if (sel && i == corner) Color.RED else stroke.color
            c.drawCircle(q.pts[i * 2], q.pts[i * 2 + 1], 6f * dp, fill)
        }
    }

    private fun drawLoupe(c: Canvas) {
        val q = quads[selected]
        val sx = q.pts[corner * 2].let { if (flipH) width - it else it }
        val sy = q.pts[corner * 2 + 1].let { if (flipV) height - it else it }
        val r = 70f * dp
        val lx = if (fingerX < width / 2f) width - r - 16f * dp else r + 16f * dp
        val ly = r + 16f * dp
        c.save()
        loupePath.reset(); loupePath.addCircle(lx, ly, r, Path.Direction.CW)
        c.clipPath(loupePath)
        c.drawColor(Color.BLACK)
        c.translate(lx, ly); c.scale(3f, 3f); c.translate(-sx, -sy)
        drawScene(c)
        c.restore()
        stroke.color = Color.WHITE
        c.drawCircle(lx, ly, r, stroke)
        c.drawLine(lx - 8f * dp, ly, lx + 8f * dp, ly, stroke)
        c.drawLine(lx, ly - 8f * dp, lx, ly + 8f * dp, stroke)
    }

    // ---------- touch ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        detector.onTouchEvent(e)
        if (projecting) return true
        val x = if (flipH) width - e.x else e.x
        val y = if (flipV) height - e.y else e.y
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                dragging = pickCorner(x, y) || pickBody(x, y)
                lastX = x; lastY = y; fingerX = e.x
            }
            MotionEvent.ACTION_MOVE -> if (dragging) {
                val k = if (fine) 0.2f else 1f // fine drag = finger moves 5x more than the point
                val dx = (x - lastX) * k; val dy = (y - lastY) * k
                lastX = x; lastY = y; fingerX = e.x
                if (corner >= 0) moveCorner(dx, dy) else moveQuad(dx, dy)
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> dragging = false
        }
        invalidate()
        return true
    }

    private fun pickCorner(x: Float, y: Float): Boolean {
        var best = 40f * dp; var bi = -1; var bk = -1
        quads.forEachIndexed { i, q ->
            for (k in 0..3) {
                val d = hypot(q.pts[k * 2] - x, q.pts[k * 2 + 1] - y)
                if (d < best) { best = d; bi = i; bk = k }
            }
        }
        if (bi < 0) return false
        selected = bi; corner = bk
        return true
    }

    private fun pickBody(x: Float, y: Float): Boolean {
        for (i in quads.indices.reversed()) if (inside(quads[i].pts, x, y)) { selected = i; corner = -1; return true }
        return false
    }

    private fun inside(p: FloatArray, x: Float, y: Float): Boolean {
        var ins = false; var j = 3
        for (i in 0..3) {
            if ((p[i * 2 + 1] > y) != (p[j * 2 + 1] > y) &&
                x < (p[j * 2] - p[i * 2]) * (y - p[i * 2 + 1]) / (p[j * 2 + 1] - p[i * 2 + 1]) + p[i * 2]) ins = !ins
            j = i
        }
        return ins
    }
}
