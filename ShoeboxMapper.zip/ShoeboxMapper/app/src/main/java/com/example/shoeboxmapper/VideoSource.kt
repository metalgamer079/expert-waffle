package com.example.shoeboxmapper

import android.graphics.Bitmap
import android.graphics.ImageFormat
import android.media.Image
import android.media.ImageReader
import android.media.MediaMetadataRetriever
import android.media.MediaPlayer
import android.os.Handler
import android.os.HandlerThread
import java.io.File
import kotlin.math.max
import kotlin.math.min

/** Plays a video muted and looping into a small Bitmap (max 320 px) that MapView warps like any other content. */
class VideoSource(private val file: File) {
    @Volatile var bitmap: Bitmap? = null
    private var player: MediaPlayer? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    @Volatile private var ready = false
    private var rot = 0
    private var bw = 1
    private var bh = 1

    fun start() {
        try {
            val r = MediaMetadataRetriever()
            r.setDataSource(file.path)
            val vw = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)!!.toInt()
            val vh = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)!!.toInt()
            rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
            r.release()
            val ow = if (rot % 180 == 0) vw else vh
            val oh = if (rot % 180 == 0) vh else vw
            val s = min(1f, 320f / max(ow, oh))
            bw = max(1, (ow * s).toInt()); bh = max(1, (oh * s).toInt())
            val t = HandlerThread("video").also { it.start() }
            thread = t
            val rd = ImageReader.newInstance(vw, vh, ImageFormat.YUV_420_888, 3)
            reader = rd
            rd.setOnImageAvailableListener({ x ->
                val img = x.acquireLatestImage()
                if (img != null) try { convert(img) } finally { img.close() }
            }, Handler(t.looper))
            player = MediaPlayer().apply {
                setDataSource(file.path)
                setSurface(rd.surface)
                isLooping = true
                setVolume(0f, 0f)
                setOnPreparedListener { ready = true; it.start() }
                prepareAsync()
            }
        } catch (e: Exception) {
            release()
        }
    }

    private fun convert(img: Image) {
        val vw = img.width; val vh = img.height
        val yP = img.planes[0]; val uP = img.planes[1]; val vP = img.planes[2]
        val yb = yP.buffer; val ub = uP.buffer; val vb = vP.buffer
        val px = IntArray(bw * bh)
        for (j in 0 until bh) {
            val v = j / bh.toFloat()
            for (i in 0 until bw) {
                val u = i / bw.toFloat()
                var sx: Int; var sy: Int
                when (rot) {
                    90 -> { sx = (v * vw).toInt(); sy = ((1 - u) * vh).toInt() }
                    180 -> { sx = ((1 - u) * vw).toInt(); sy = ((1 - v) * vh).toInt() }
                    270 -> { sx = ((1 - v) * vw).toInt(); sy = (u * vh).toInt() }
                    else -> { sx = (u * vw).toInt(); sy = (v * vh).toInt() }
                }
                sx = sx.coerceIn(0, vw - 1); sy = sy.coerceIn(0, vh - 1)
                val y = yb.get(sy * yP.rowStride + sx * yP.pixelStride).toInt() and 0xFF
                val cu = (ub.get((sy / 2) * uP.rowStride + (sx / 2) * uP.pixelStride).toInt() and 0xFF) - 128
                val cv = (vb.get((sy / 2) * vP.rowStride + (sx / 2) * vP.pixelStride).toInt() and 0xFF) - 128
                val r = (y + ((1436 * cv) shr 10)).coerceIn(0, 255)
                val g = (y - ((352 * cu + 731 * cv) shr 10)).coerceIn(0, 255)
                val b = (y + ((1814 * cu) shr 10)).coerceIn(0, 255)
                px[j * bw + i] = (0xFF shl 24) or (r shl 16) or (g shl 8) or b
            }
        }
        val bmp = bitmap ?: Bitmap.createBitmap(bw, bh, Bitmap.Config.ARGB_8888).also { bitmap = it }
        bmp.setPixels(px, 0, bw, 0, 0, bw, bh)
    }

    fun pause() { try { if (ready) player?.pause() } catch (e: Exception) {} }
    fun resume() { try { if (ready) player?.start() } catch (e: Exception) {} }

    fun release() {
        ready = false
        try { player?.release() } catch (e: Exception) {}
        try { reader?.close() } catch (e: Exception) {}
        thread?.quitSafely()
        player = null; reader = null; thread = null
    }
}
