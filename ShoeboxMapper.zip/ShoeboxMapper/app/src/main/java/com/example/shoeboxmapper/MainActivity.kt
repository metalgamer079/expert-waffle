package com.example.shoeboxmapper

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var map: MapView
    private lateinit var controls: LinearLayout
    private var target = 0
    private var stepIdx = 1
    private val steps = floatArrayOf(0.5f, 1f, 4f)
    private val targets = arrayOf("Corner", "Quad", "Scene")

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::loadPhoto) }
    private val pickMedia = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::attachMedia) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.attributes = window.attributes.apply { screenBrightness = 1f }

        map = MapView(this)
        map.onToggle = { setProjecting(false) }

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            addView(row(
                btn("Photo") { pickPhoto.launch("image/*") },
                btn("Photo on/off") { map.showPhoto = !map.showPhoto; map.invalidate() },
                btn("+ Quad") { map.addQuad() },
                btn("Delete") { map.deleteSelected() },
                btn("Content") { chooseContent() },
                btn("Flip H") { map.flipH = !map.flipH; map.invalidate() },
                btn("Flip V") { map.flipV = !map.flipV; map.invalidate() },
                btn("PROJECT") { setProjecting(true) }
            ))
            addView(row(
                btn("Target: Corner") { target = (target + 1) % 3; it.text = "Target: ${targets[target]}" },
                btn("Step: 1px") { stepIdx = (stepIdx + 1) % 3; it.text = "Step: ${steps[stepIdx]}px" },
                btn("Fine drag: off") { map.fine = !map.fine; it.text = "Fine drag: ${if (map.fine) "on" else "off"}" },
                btn("◀") { nudge(-1f, 0f) }, btn("▲") { nudge(0f, -1f) },
                btn("▼") { nudge(0f, 1f) }, btn("▶") { nudge(1f, 0f) },
                btn("Z−") { map.zoomAll(0.99f) }, btn("Z+") { map.zoomAll(1.01f) }
            ))
        }

        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(controls, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
        loadState()
    }

    override fun onPause() { super.onPause(); saveState() }

    // ---------- UI helpers ----------
    private fun btn(label: String, action: (Button) -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        minWidth = 0; minimumWidth = 0
        setOnClickListener { action(this) }
    }

    private fun row(vararg buttons: Button): HorizontalScrollView {
        val ll = LinearLayout(this)
        buttons.forEach { ll.addView(it) }
        return HorizontalScrollView(this).apply { addView(ll) }
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun setProjecting(on: Boolean) {
        map.projecting = on
        controls.visibility = if (on) View.GONE else View.VISIBLE
        if (on) saveState()
        map.invalidate()
    }

    /** Arrows move things in wall space: "right" is right on the wall, even when the screen is flipped. */
    private fun nudge(dx: Float, dy: Float) {
        val s = steps[stepIdx]
        when (target) {
            0 -> map.moveCorner(dx * s, dy * s)
            1 -> map.moveQuad(dx * s, dy * s)
            else -> map.moveAll(dx * s, dy * s)
        }
    }

    // ---------- content ----------
    private fun chooseContent() {
        if (map.selected !in map.quads.indices) { toast("Tap a quad first"); return }
        AlertDialog.Builder(this).setTitle("Content for selected quad")
            .setItems(arrayOf<CharSequence>("GIF / image from phone", "Solid color", "Pulsing color", "Moving stripes")) { _, i ->
                when (i) {
                    0 -> pickMedia.launch("image/*")
                    1 -> askColor(Kind.COLOR)
                    2 -> askColor(Kind.PULSE)
                    else -> askColor(Kind.STRIPES)
                }
            }.show()
    }

    private fun askColor(kind: Kind) {
        val names = arrayOf<CharSequence>("White", "Red", "Green", "Blue", "Yellow", "Magenta", "Cyan")
        val cols = intArrayOf(Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.CYAN)
        AlertDialog.Builder(this).setTitle("Color").setItems(names) { _, i ->
            map.quads.getOrNull(map.selected)?.let { it.kind = kind; it.color = cols[i]; it.drawable = null }
            map.invalidate()
        }.show()
    }

    private fun attachMedia(uri: Uri) {
        val q = map.quads.getOrNull(map.selected) ?: return
        val name = "media_${System.currentTimeMillis()}"
        contentResolver.openInputStream(uri)?.use { i -> File(filesDir, name).outputStream().use { i.copyTo(it) } }
        q.mediaFile = name; q.kind = Kind.MEDIA
        map.loadMedia(q); map.invalidate()
    }

    private fun loadPhoto(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val s = max(info.size.width, info.size.height) / 2048f
                if (s > 1f) dec.setTargetSampleSize(ceil(s).toInt())
            }
            File(filesDir, "photo.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            map.photo = bmp; map.showPhoto = true; map.invalidate()
        } catch (e: Exception) {
            toast("Couldn't load photo")
        }
    }

    // ---------- persistence ----------
    private fun saveState() {
        val arr = JSONArray()
        map.quads.forEach { q ->
            arr.put(JSONObject()
                .put("pts", JSONArray(q.pts.map { it.toDouble() }))
                .put("kind", q.kind.name).put("color", q.color)
                .put("media", q.mediaFile ?: JSONObject.NULL))
        }
        getPreferences(MODE_PRIVATE).edit()
            .putString("quads", arr.toString()).putBoolean("fh", map.flipH).putBoolean("fv", map.flipV).apply()
    }

    private fun loadState() {
        val prefs = getPreferences(MODE_PRIVATE)
        map.flipH = prefs.getBoolean("fh", false); map.flipV = prefs.getBoolean("fv", false)
        prefs.getString("quads", null)?.let { s ->
            try {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i); val p = o.getJSONArray("pts")
                    val q = Quad(FloatArray(8) { p.getDouble(it).toFloat() }, Kind.valueOf(o.getString("kind")),
                        o.getInt("color"), if (o.isNull("media")) null else o.getString("media"))
                    map.loadMedia(q); map.quads.add(q)
                }
            } catch (e: Exception) { /* ignore corrupt state */ }
        }
        File(filesDir, "photo.jpg").takeIf { it.exists() }?.let { map.photo = BitmapFactory.decodeFile(it.path) }
    }
}
