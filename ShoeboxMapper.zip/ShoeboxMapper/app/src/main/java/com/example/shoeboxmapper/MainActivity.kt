package com.example.shoeboxmapper

import android.app.AlertDialog
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.ImageDecoder
import android.graphics.Typeface
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.addCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.max

class MainActivity : ComponentActivity() {
    private lateinit var map: MapView
    private lateinit var controls: LinearLayout
    private lateinit var menu: LinearLayout
    private var target = 0
    private var stepIdx = 1
    private val steps = floatArrayOf(0.5f, 1f, 4f)
    private val targets = arrayOf("Corner", "Quad", "Scene")

    private val pickPhoto = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::loadPhoto) }
    private val pickVideo = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::attachVideo) }
    private val pickMedia = registerForActivityResult(ActivityResultContracts.GetContent()) { it?.let(::attachMedia) }

    private fun dp(n: Int) = (n * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            hide(WindowInsetsCompat.Type.systemBars())
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.attributes = window.attributes.apply { screenBrightness = 1f }

        map = MapView(this)
        map.onToggle = { setProjecting(false) }

        val project = btn("▶  PROJECT  (hides this menu)") { setProjecting(true) }.apply {
            setBackgroundColor(0xFF1B8A3A.toInt()); textSize = 14f; setTypeface(typeface, Typeface.BOLD)
        }
        val top = LinearLayout(this).apply {
            addView(btn("☰ Menu") { showMenu(true) }, LinearLayout.LayoutParams(WRAP_CONTENT, WRAP_CONTENT))
            addView(project, LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f))
        }
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(0xAA000000.toInt())
            addView(top)
            addView(row(
                btn("Photo") { pickPhoto.launch("image/*") },
                btn("Photo on/off") { map.showPhoto = !map.showPhoto; map.invalidate() },
                btn("+ Quad") { map.addQuad() },
                btn("Delete") { map.deleteSelected() },
                btn("Content") { chooseContent() },
                btn("Flip H") { map.flipH = !map.flipH; map.invalidate() },
                btn("Flip V") { map.flipV = !map.flipV; map.invalidate() }
            ))
            addView(row(
                btn("Target: Corner") { target = (target + 1) % 3; it.text = "Target: ${targets[target]}" },
                btn("Step: 1px") { stepIdx = (stepIdx + 1) % 3; it.text = "Step: ${steps[stepIdx]}px" },
                btn("Fine drag: off") { map.fine = !map.fine; it.text = "Fine drag: ${if (map.fine) "on" else "off"}" },
                btn("◀") { nudge(-1f, 0f) }, btn("▲") { nudge(0f, -1f) },
                btn("▼") { nudge(0f, 1f) }, btn("▶") { nudge(1f, 0f) },
                btn("Z−") { map.zoomAll(0.99f) }, btn("Z+") { map.zoomAll(1.01f) }
            ))
        }
        menu = buildMenu()

        val root = FrameLayout(this)
        root.addView(map, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        root.addView(controls, FrameLayout.LayoutParams(MATCH_PARENT, WRAP_CONTENT, Gravity.BOTTOM))
        root.addView(menu, FrameLayout.LayoutParams(MATCH_PARENT, MATCH_PARENT))
        setContentView(root)
        loadState()
        showMenu(true)

        onBackPressedDispatcher.addCallback(this) {
            when {
                map.projecting -> setProjecting(false)
                menu.visibility != View.VISIBLE -> showMenu(true)
                else -> finish()
            }
        }
    }

    override fun onPause() { super.onPause(); saveState(); map.pauseVideos() }
    override fun onResume() { super.onResume(); map.resumeVideos() }

    // ---------- UI helpers ----------
    private fun btn(label: String, action: (Button) -> Unit) = Button(this).apply {
        text = label; isAllCaps = false; textSize = 12f; setTextColor(Color.WHITE)
        minWidth = 0; minimumWidth = 0
        setOnClickListener { action(this) }
    }

    private fun row(vararg buttons: Button): HorizontalScrollView {
        val ll = LinearLayout(this)
        buttons.forEach { ll.addView(it) }
        return HorizontalScrollView(this).apply { addView(ll) }
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        this.text = text; textSize = size; setTextColor(color); gravity = Gravity.CENTER
        if (bold) setTypeface(typeface, Typeface.BOLD)
    }

    private fun toast(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun buildMenu(): LinearLayout {
        fun big(text: String, color: Int, action: () -> Unit) = btn(text) { action() }.apply {
            textSize = 16f; setBackgroundColor(color); setPadding(dp(16), dp(20), dp(16), dp(20))
        }
        val buttons = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(28), dp(16), 0)
            val lp = { LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f).apply { setMargins(dp(6), 0, dp(6), 0) } }
            addView(big("▶\nStart mapping", 0xFF1B8A3A.toInt()) { showMenu(false) }, lp())
            addView(big("📷\nLoad wall photo", 0xFF3D4CC4.toInt()) { showMenu(false); pickPhoto.launch("image/*") }, lp())
            addView(big("🗑\nClear all quads", 0xFF9C2F2F.toInt()) { confirmClear() }, lp())
            addView(big("?\nHow it works", 0xFF555566.toInt()) { showHelp() }, lp())
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setBackgroundColor(0xFF0B0B1A.toInt())
            isClickable = true
            addView(label("SHOEBOX MAPPER", 34f, Color.WHITE, true))
            addView(label("projection mapping for your DIY projector", 14f, 0xFF9AA0FF.toInt()))
            addView(buttons)
        }
    }

    private fun showMenu(on: Boolean) {
        if (on) saveState()
        menu.visibility = if (on) View.VISIBLE else View.GONE
        controls.visibility = if (on || map.projecting) View.GONE else View.VISIBLE
    }

    private fun showHelp() = AlertDialog.Builder(this).setTitle("How it works").setMessage(
        "1. Take a photo of your wall from where the box will sit (camera app), then tap Load wall photo.\n\n" +
        "2. + Quad adds a shape. Drag its corners onto a door, frame or window.\n\n" +
        "3. Content: pick your GIF or a pattern for each quad.\n\n" +
        "4. Flip H / Flip V to match your lens.\n\n" +
        "5. Fine-tune with Fine drag, the arrows and the loupe.\n\n" +
        "6. PROJECT hides everything. Double-tap the screen or press Back to bring the controls back."
    ).setPositiveButton("OK", null).show()

    private fun confirmClear() = AlertDialog.Builder(this).setTitle("Delete all quads?")
        .setPositiveButton("Delete") { _, _ -> map.quads.forEach { it.video?.release() }; map.quads.clear(); map.selected = -1; map.corner = -1; map.invalidate() }
        .setNegativeButton("Cancel", null).show()

    private fun setProjecting(on: Boolean) {
        map.projecting = on
        controls.visibility = if (on) View.GONE else View.VISIBLE
        if (on) { saveState(); toast("Double-tap or press Back to bring the controls back") }
        map.invalidate()
    }

    /** Arrows move things in wall space: "right" is right on the wall, even when the screen is flipped. */
    private fun nudge(dx: Float, dy: Float) {
        val s = steps[stepIdx]
        when (target) {
            0 -> map.moveCorner(dx * s, dy * s)
            1 -> map.moveQuad(dx * s, dy * s)
            else -> map.moveAll(dx * s, dy * s)
        }
    }

    // ---------- content ----------
    private fun chooseContent() {
        if (map.selected !in map.quads.indices) { toast("Tap a quad first"); return }
        AlertDialog.Builder(this).setTitle("Content for selected quad")
            .setItems(arrayOf<CharSequence>("GIF / image from phone", "Video from phone (muted, loops)", "Solid color", "Pulsing color",
                "Moving stripes", "Moving checkerboard", "Rainbow")) { _, i ->
                when (i) {
                    0 -> pickMedia.launch("image/*")
                    1 -> pickVideo.launch("video/*")
                    2 -> askColor(Kind.COLOR)
                    3 -> askColor(Kind.PULSE)
                    4 -> askColor(Kind.STRIPES)
                    5 -> askColor(Kind.CHECKER)
                    else -> map.quads.getOrNull(map.selected)?.let { it.kind = Kind.RAINBOW; it.drawable = null; map.invalidate() }
                }
            }.show()
    }

    private fun askColor(kind: Kind) {
        val names = arrayOf<CharSequence>("White", "Red", "Green", "Blue", "Yellow", "Magenta", "Cyan")
        val cols = intArrayOf(Color.WHITE, Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW, Color.MAGENTA, Color.CYAN)
        AlertDialog.Builder(this).setTitle("Color").setItems(names) { _, i ->
            map.quads.getOrNull(map.selected)?.let { it.kind = kind; it.color = cols[i]; it.drawable = null }
            map.invalidate()
        }.show()
    }

    private fun attachMedia(uri: Uri) {
        val q = map.quads.getOrNull(map.selected) ?: return
        val name = "media_${System.currentTimeMillis()}"
        contentResolver.openInputStream(uri)?.use { i -> File(filesDir, name).outputStream().use { i.copyTo(it) } }
        q.mediaFile = name; q.kind = Kind.MEDIA
        map.loadMedia(q); map.invalidate()
    }

    private fun attachVideo(uri: Uri) {
        val q = map.quads.getOrNull(map.selected) ?: return
        val name = "media_${System.currentTimeMillis()}"
        contentResolver.openInputStream(uri)?.use { i -> File(filesDir, name).outputStream().use { i.copyTo(it) } }
        q.mediaFile = name; q.kind = Kind.VIDEO; q.drawable = null
        map.loadMedia(q); map.invalidate()
    }

    private fun loadPhoto(uri: Uri) {
        try {
            val bmp = ImageDecoder.decodeBitmap(ImageDecoder.createSource(contentResolver, uri)) { dec, info, _ ->
                dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
                val s = max(info.size.width, info.size.height) / 2048f
                if (s > 1f) dec.setTargetSampleSize(ceil(s).toInt())
            }
            File(filesDir, "photo.jpg").outputStream().use { bmp.compress(Bitmap.CompressFormat.JPEG, 90, it) }
            map.photo = bmp; map.showPhoto = true; map.invalidate()
        } catch (e: Exception) {
            toast("Couldn't load photo")
        }
    }

    // ---------- persistence ----------
    private fun saveState() {
        val arr = JSONArray()
        map.quads.forEach { q ->
            arr.put(JSONObject()
                .put("pts", JSONArray(q.pts.map { it.toDouble() }))
                .put("kind", q.kind.name).put("color", q.color)
                .put("media", q.mediaFile ?: JSONObject.NULL))
        }
        getPreferences(MODE_PRIVATE).edit()
            .putString("quads", arr.toString()).putBoolean("fh", map.flipH).putBoolean("fv", map.flipV).apply()
    }

    private fun loadState() {
        val prefs = getPreferences(MODE_PRIVATE)
        map.flipH = prefs.getBoolean("fh", false); map.flipV = prefs.getBoolean("fv", false)
        prefs.getString("quads", null)?.let { s ->
            try {
                val arr = JSONArray(s)
                for (i in 0 until arr.length()) {
                    val o = arr.getJSONObject(i); val p = o.getJSONArray("pts")
                    val q = Quad(FloatArray(8) { p.getDouble(it).toFloat() }, Kind.valueOf(o.getString("kind")),
                        o.getInt("color"), if (o.isNull("media")) null else o.getString("media"))
                    map.loadMedia(q); map.quads.add(q)
                }
            } catch (e: Exception) { /* ignore corrupt state */ }
        }
        File(filesDir, "photo.jpg").takeIf { it.exists() }?.let { map.photo = BitmapFactory.decodeFile(it.path) }
    }
}
