# Shoebox Mapper
1. Android Studio -> File > Open -> select this folder. Let Gradle sync (needs internet once).
2. Plug in your phone (USB debugging on) -> Run, or Build > Build APK(s).
3. In the app: take a photo of your wall from the box position with your camera app, tap "Photo" to load it,
   "+ Quad" to add a shape, drag its corners onto a surface, "Content" to pick your Susie GIF, then Flip H/V
   as your lens needs, fine-tune live, and tap PROJECT. Double-tap the screen to get the controls back.
